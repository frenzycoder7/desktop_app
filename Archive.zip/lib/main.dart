import 'package:flutter/material.dart';
import 'package:videoplayer/videoplayer.dart';

void main() {
  runApp(PlayerView());
}

class PlayerView extends StatelessWidget {
  PlayerView({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Video Player",
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Player View'),
        ),
        body: VisionVideoPlayer(
          builder: (context, child) {
            return child;
          },
          onControllerChange: (p0) {},
          videoUrl:
              "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8",
        ),
      ),
    );
  }
}
